// *****************************************************************************
// Sample.cs
// A sample class to demonstrate the usage of C# XMP Toolkit
//
// In order to run this code you must:
// - Add a reference to CsXmpToolkit.dll
//   (already done for the XmpSample project)
// - Copy the XmpToolkit.dll to the output directory
//   (this is done automatically for the XmpSample project)
// *****************************************************************************
using System;
using SE.Halligang.CsXmpToolkit;
using SE.Halligang.CsXmpToolkit.Schemas;

namespace XmpSample
{
	public static class Sample
	{
		public static void Run()
		{
			// The C# XMP Toolkit consists of two parts,
			// - a wrapper around the XMP Toolkit
			// - schema helper classes

			// Change the following to the full path of an image of your choice.
			filePath = @"c:\myfolder\myimage.jpg";

			// Test the XMP Toolkit
			TestToolkit();

			// Test the schema helper classes of C# XMP Toolkit
			TestSchemas();
		}

		private static string filePath;

		#region Toolkit

		/// <summary>
		/// Please download the XMP Toolkit from Adobe
		/// and read the documentation for more information.
		/// http://www.adobe.com/devnet/xmp/
		/// </summary>
		private static void TestToolkit()
		{
			if (XmpCore.Initialize() && XmpFiles.Initialize())
			{
				using (XmpFiles xmpFiles = new XmpFiles(filePath, FileFormat.Unknown, OpenFlags.OpenForUpdate | OpenFlags.OpenUseSmartHandler | OpenFlags.OpenCacheTNail))
				{
					using (XmpCore xmpCore = new XmpCore())
					{
						if (xmpFiles.GetXmp(xmpCore))
						{
							// Read the Dublin Core Schema
							// NOTE: Only source, subject and title are read!
							string dcNS = "http://purl.org/dc/elements/1.1/";
							PropertyFlags options;

							string source;
							xmpCore.GetProperty(dcNS, "source", out source, out options);
							if (source != null)
							{
								// Use source here...
							}

							XmpIterator iter = new XmpIterator(xmpCore, dcNS, "subject", IteratorMode.JustChildren);
							string schemaNS;
							string propPath;
							string propValue;
							while (iter.Next(out schemaNS, out propPath, out propValue, out options))
							{
								// Use subject (propValue) here...
							}

							iter = new XmpIterator(xmpCore, dcNS, "title", IteratorMode.JustChildren);
							while (iter.Next(out schemaNS, out propPath, out propValue, out options))
							{
								string langNS = "http://www.w3.org/XML/1998/namespace";
								string language;
								if (xmpCore.GetQualifier(dcNS, propPath, langNS, "lang", out language, out options))
								{
									// Use title, language and value (propValue), here...
								}
							}
						}
					}
				}

				XmpFiles.Terminate();
				XmpCore.Terminate();
			}

			// The above code uses the XMP Toolkit. The corresponding code using
			// the C# XMP Toolkit would be:
			using (Xmp xmp = Xmp.FromFile(filePath, XmpFileMode.ReadOnly))
			{
				DublinCore dc = new DublinCore(xmp);
				if (dc.Source != null)
				{
					// Use source here...
				}
				foreach (string subject in dc.Subject)
				{
					// Use subject here...
				}
				foreach (LangEntry langEntry in dc.Title)
				{
					// Use title, langEntry.Language and langEntry.Value, here...
				}
			}
		}

		#endregion

		#region Schemas

		private static void TestSchemas()
		{
			// Create an Xmp object with the "using" keyword for
			// an automatic Dispose.

			// This will automatically Initialize the Toolkit when
			// created and Terminate the toolkit when disposed.
			// If more than one file is to be opened then it is
			// more efficient to manually initialize and terminate
			// the toolkit. Uncomment the following line to do so:
			//Xmp.Initialize();

			// ReadWrite will read XMP (if any) and allows update.
			// ReadOnly will read XMP (if any) and won't update.
			// WriteOnly will not read XMP, even if it exists, and
			// will overwrite when updating.
			using (Xmp xmp = Xmp.FromFile(filePath, XmpFileMode.ReadWrite))
			{
				// See the original XMP.
				// Set a breakpoint on the following line and
				// inspect the xmpDump variable.
				string xmpDump = xmp.Dump();

				// Test the schemas available in this release.
				// Some general comments:
				// To remove a property from XMP; Clear() arrays and set values to null.
				// Likewise, empty lists and null values did not exist in XMP.

				// The following schemas are defined in Adobe XMP Specification:
				// http://www.adobe.com/devnet/xmp/pdfs/xmp_specification.pdf
				TestDublinCore(xmp);
				TestExifAdditional(xmp);
				TestExifSpecific(xmp);
				TestExifTiff(xmp);
				TestPdf(xmp);
				TestPhotoshop(xmp);
				TestRaw(xmp);
				TestXmpBasic(xmp);
				TestXmpDynamic(xmp);
				TestXmpMedia(xmp);
				TestXmpRights(xmp);
				TestXmpText(xmp);
				TestXmpTicket(xmp);

				// The following schema is defined in Image Map Specification:
				// http://www.halligang.se/xmp/imageMap-specification.pdf
				TestImageMap(xmp);

				// The following schema is defined in IPTC Specification:
				// http://www.iptc.org/std/Iptc4xmpCore/1.0/specification/Iptc4xmpCore_1.0-spec-XMPSchema_8.pdf
				TestIptc(xmp);

				// The following schema is defined in Personal Classification Specification:
				// http://www.halligang.se/xmp/pcs-specification.pdf
				TestPersonalClassification(xmp);

				// See what's about to be stored.
				// Set a breakpoint on the following line and
				// inspect the xmpDump variable.
				xmpDump = xmp.Dump();

				// Save XMP.
				xmp.Save();
			}

			// If the Toolkit was manually initialized, it must alos
			// be terminated. Uncomment the following line to do so:
			//Xmp.Terminate();
		}

		private static void TestDublinCore(Xmp xmp)
		{
			DublinCore dc = new DublinCore(xmp);
			dc.Source = "XmpSample project";
			dc.Subject.Clear();
			dc.Subject.Add("XmpSample");
			dc.Title["x-default"] = "C# XMP Toolkit sample";
		}

		private static void TestExifAdditional(Xmp xmp)
		{
		}

		private static void TestExifSpecific(Xmp xmp)
		{
		}

		private static void TestExifTiff(Xmp xmp)
		{
		}

		private static void TestPdf(Xmp xmp)
		{
		}

		private static void TestPhotoshop(Xmp xmp)
		{
			Photoshop ps = new Photoshop(xmp);
			ps.Instructions = "Handle with care...";
		}

		private static void TestRaw(Xmp xmp)
		{
		}

		private static void TestXmpBasic(Xmp xmp)
		{
			XmpBasic basic = new XmpBasic(xmp);
			basic.MetadataDate = DateTime.Now;
			basic.Rating = 5;
		}

		private static void TestXmpDynamic(Xmp xmp)
		{
		}

		private static void TestXmpMedia(Xmp xmp)
		{
		}

		private static void TestXmpRights(Xmp xmp)
		{
			XmpRights rights = new XmpRights(xmp);
			rights.Owner.Clear();
			rights.Owner.Add("Martin Sanneblad");
			rights.UsageTerms["x-default"] = "Sample provided to test with C# XMP Toolkit.";
		}

		private static void TestXmpText(Xmp xmp)
		{
		}

		private static void TestXmpTicket(Xmp xmp)
		{
		}

		private static void TestImageMap(Xmp xmp)
		{
			ImageMap im = new ImageMap(xmp);
			im.ImageSize.SetDimensions(1024, 768, "pixel");
			im.Areas.Add(new Area(
				ShapeType.Rectangle,
				new int[] { 100, 100, 200, 200 },
				new LangEntry[] { new LangEntry("x-default", "Martin") },
				null,
				null));
		}

		private static void TestIptc(Xmp xmp)
		{
			Iptc iptc = new Iptc(xmp);
			iptc.CopyrightNotice["x-default"] = "Copyright (c) 2007 Martin Sanneblad";
		}

		private static void TestPersonalClassification(Xmp xmp)
		{
			PersonalClassification pc = new PersonalClassification(xmp);
			pc.Creator = "Martin Sanneblad";
			pc.Classifications.Add(new Classification("Martin", ClassificationType.Descriptive, new string[] { "People", "Owners" }));
		}

		#endregion
	}
}
