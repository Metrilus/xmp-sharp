using System;
using SE.Halligang.CsXmpToolkit.Schemas;

namespace XmpSample
{
	public static class Sample
	{
		/// <summary>
		/// Available schemas in this release:
		/// - DublinCore
		/// - Iptc
		/// - Photoshop
		/// - XmpBasic (except for Thumbnail property)
		/// - XmpRights
		/// </summary>
		private static void TestSchemas()
		{
			// Update Title, Keywords and Rating.
			using (Xmp xmp = Xmp.FromFile("sample.jpg", XmpFileMode.ReadWrite))
			{
				DublinCore dc = new DublinCore(xmp);
				dc.Title["x-default"] = "A sample image";
				dc.Subject.Clear();
				dc.Subject.Add("a");
				dc.Subject.Add("sample");
				dc.Subject.Add("image");

				XmpBasic basic = new XmpBasic(xmp);
				basic.Rating = 5;
				basic.MetadataDate = DateTime.Now;

				// See what's about to be stored.
				string xmpDump = xmp.Dump();

				xmp.Save();
			}
		}
	}
}
