C# XMP Toolkit
--------------

This is a wrapper/extender for Adobe's XMP Toolkit.

It wraps all the functionality of the XMP Toolkit and extends with schema handlers for very easy editing of XMP.

The contents of the download archive should be:

\XmpSample             A directory containing a detailed sample.
CsXmpToolkit.dll       The C# XMP Toolkit.
CsXmpToolkit.eula.txt  The license for using the C# XMP Toolkit.
readme.txt             This file.
XmpToolkit.dll         The XMP Toolkit.
XmpToolkit.eula.txt    The license for using the XMP Toolkit.


If you find the C# XMP Toolkit to be useful or if you have any comments or questions, please send an e-mail to:

xmp@halligang.se
NOTE: you must use the subject "C# XMP Toolkit Feedback" (without quotes).

Or you can visit the website:

http://www.halligang.se/xmp/


Have fun!
Martin