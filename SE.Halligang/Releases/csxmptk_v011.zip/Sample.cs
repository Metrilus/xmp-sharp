using System;
using System.Drawing;
using System.Drawing.Imaging;
using System.Text;
using System.Windows.Forms;
using SE.Halligang.Xmp;
using SE.Halligang.Xmp.Schemas;
using System.Globalization;
using System.Collections.Generic;

namespace XmpSample
{
	public class Sample
	{
		public void SimpleExtraction()
		{
			// Open an image and extract title, keywords and rating.

			// Initialize XMP Toolkit
			if (XmpCore.Initialize() && XmpFiles.Initialize())
			{
				try
				{
					// Create XMPFiles object
					using (XmpFiles xmpFiles = new XmpFiles())
					{
						// Open an image file for read only
						string filePath = Application.StartupPath + @"\Sample.jpg";
						OpenFlags smartScanningFlags = OpenFlags.OpenForRead | OpenFlags.OpenUseSmartHandler;
						OpenFlags packetScanningFlags = OpenFlags.OpenForRead | OpenFlags.OpenUsePacketScanning;
						if (xmpFiles.OpenFile(filePath, FileFormat.Unknown, smartScanningFlags) ||
							xmpFiles.OpenFile(filePath, FileFormat.Unknown, packetScanningFlags))
						{
							// Create XMPCore object
							using (XmpCore xmpCore = new XmpCore())
							{
								// Get XMP from file
								if (xmpFiles.GetXmp(xmpCore))
								{
									// Get title and keywords (contained in Dublin Core Schema)
									DublinCore dc = new DublinCore(xmpCore);
									if (dc.Title.Count > 0 && dc.Title.ContainsKey("x-default"))
									{
										MessageBox.Show("Title: " + dc.Title["x-default"]);
									}
									else
									{
										MessageBox.Show("<No title>");
									}
									if (dc.Subject.Count > 0)
									{
										StringBuilder keywords = new StringBuilder();
										foreach (string keyword in dc.Subject)
										{
											keywords.Append("\r\n" + keyword);
										}
										MessageBox.Show("Keywords:" + keywords.ToString());
									}
									else
									{
										MessageBox.Show("<No keywords>");
									}

									// Get rating (contained in XMP Basic Schema)
									XmpBasic xap = new XmpBasic(xmpCore);
									if (xap.Rating != null)
									{
										MessageBox.Show("Rating: " + xap.Rating.ToString());
									}
									else
									{
										MessageBox.Show("<No rating>");
									}									
								}
							}

							// Close file when done with it
							xmpFiles.CloseFile(CloseFlags.None);
						}
					}
				}
				catch (Exception ex)
				{
					// Handle exceptions
				}
				finally
				{
					// Terminate XMP Toolkit
					XmpFiles.Terminate();
					XmpCore.Terminate();
				}
			}
		}

		public void ExtensiveSample()
		{
			// Get version information
			XmpVersionInfo coreVersion = XmpCore.GetVersionInfo();
			XmpVersionInfo filesVersion = XmpFiles.GetVersionInfo();

			// Initialize XMP Toolkit
			if (XmpCore.Initialize() && XmpFiles.Initialize())
			{
				try
				{
					// Get format information for JPEG
					FileFormatInfo formatInfo = new FileFormatInfo(FileFormat.Jpeg);

					// Register custom namespace
					const string hmxNamespaceUri = "http://custom.custom/custom/1.0/";
					const string hmxPreferredPrefix = "custom";
					string hmxPrefix;
					if (!XmpCore.RegisterNamespace(hmxNamespaceUri, hmxPreferredPrefix, out hmxPrefix))
					{
						// The preferred prefix is not available.
						string registeredNamespace;
						if (XmpCore.GetNamespaceURI(hmxPreferredPrefix, out registeredNamespace))
						{
							// The namespace URI that has the prefix registered is now in "registeredNamespace".
						}
						else
						{
							// Unable to retrieve which namespace URI has the prefix registered.
						}
					}

					// Create XMPFiles object
					using (XmpFiles xmpFiles = new XmpFiles())
					{
						// Open an image file for read/write
						string filePath = Application.StartupPath + @"\Sample.jpg";
						OpenFlags smartScanningFlags = OpenFlags.OpenForUpdate | OpenFlags.OpenUseSmartHandler | OpenFlags.OpenCacheTNail;
						OpenFlags packetScanningFlags = OpenFlags.OpenForUpdate | OpenFlags.OpenUsePacketScanning;
						if (xmpFiles.OpenFile(filePath, FileFormat.Unknown, smartScanningFlags) ||
							xmpFiles.OpenFile(filePath, FileFormat.Unknown, packetScanningFlags))
						{
							// Get information about the opened file
							OpenFlags openFlags;
							FileFormat fileFormat;
							int handlerFlags;
							if (xmpFiles.GetFileInfo(out openFlags, out fileFormat, out handlerFlags))
							{
							}

							// Get thumbnail
							ThumbnailInfo thumbnailInfo;
							if (xmpFiles.GetThumbnail(out thumbnailInfo))
							{
								Image thumbnail = thumbnailInfo.GetThumbnail();
								if (thumbnail != null)
								{
									thumbnail.Save(Application.StartupPath + @"\Sample_thumb.jpg", ImageFormat.Jpeg);
								}
							}

							// Create XMPCore object
							using (XmpCore xmpCore = new XmpCore())
							{
								// Get XMP from file
								PacketInfo packetInfo = new PacketInfo();
								string xmpPacket;
								if (xmpFiles.GetXmp(xmpCore, packetInfo, out xmpPacket))
								{
									// Read and modify Dublin Core Schema
									DublinCore dc = new DublinCore(xmpCore);
									dc.Title.Clear();
									dc.Title.Add("x-default", "Having some coffee.");
									dc.Title.Add("en-US", "Having some coffee.");
									dc.Title.Add("sv-SE", "Dricker lite kaffe.");

									// Read and modify XMP Basic Schema
									XmpBasic xap = new XmpBasic(xmpCore);
									xap.Rating = 4;
									xap.MetadataDate = DateTime.Now;

									// Dump XMP
									StringBuilder xmpDump = new StringBuilder();
									xmpCore.DumpObject(new TextOutputDelegate(TextOutput), xmpDump);

									// Save xmp
									if (xmpFiles.CanPutXmp(xmpCore))
									{
										xmpFiles.PutXmp(xmpCore);
									}
								}
							}

							// Close file when done with it
							xmpFiles.CloseFile(CloseFlags.UpdateSafely);
						}
					}
				}
				catch (Exception ex)
				{
					// Handle exceptions
				}
				finally
				{
					// Terminate XMP Toolkit
					XmpFiles.Terminate();
					XmpCore.Terminate();
				}
			}
		}

		private void TextOutput(object state, string textOutput)
		{
			StringBuilder sb = (StringBuilder)state;
			sb.Append(textOutput);
		}
	}
}